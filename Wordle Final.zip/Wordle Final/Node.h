using namespace std;

#ifndef NODE_H
#define NODE_H

class Node
{
    public:
    string key;
    Node *left;
    Node *right;
    int height;
};

#endif /* NODE_H */

