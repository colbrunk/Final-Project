#include <iostream>
#include <fstream>
#include <time.h>
#include "hash.h"
#include "tree.h"
#include "node.h"
#include "graph.h"

using namespace std;

//Recursive Sort

int minIndex(int a[], int i, int j) {
    if (i == j)
        return i;
    int k = minIndex(a, i + 1, j);
    return (a[i] < a[k]) ? i : k;
}

void recurSelectionSort(int a[], int n, int index = 0) {
    if (index == n)
        return;
    int k = minIndex(a, index, n - 1);
    if (k != index)
        swap(a[k], a[index]);
    return recurSelectionSort(a, n, index + 1);
}

//Output word accuracy

void printProgress(char a[], int size) {
    for (int count = 0; count < size; count++) {
        if (a[count] == 'x') {
            cout << "_ ";
        } else {
            cout << a[count] << " ";
        }
    }
    cout << endl;
}

//Check if letter is in the word being guessed

bool findLetter(char a, string b, int c) {
    int x = c;
    if (x == 5)
        return false;
    else {
        if (a == b[x])
            return true;
    }
    return findLetter(a, b, c + 1);
}

bool findLetter4(char a, string b, int c) {
    int x = c;
    if (x == 4)
        return false;
    else {
        if (a == b[x])
            return true;
    }
    return findLetter4(a, b, c + 1);
}

bool findLetter6(char a, string b, int c) {
    int x = c;
    if (x == 6)
        return false;
    else {
        if (a == b[x])
            return true;
    }
    return findLetter6(a, b, c + 1);
}

//Convert word to all uppercase

string lowerUpper(string a, int b) {
    int x = b;
    if (x == 5) {
        return a;
    } else {
        if (a[x] >= 'a' && a[x] <= 'z') {
            int ascii = a[x];
            ascii = ascii - 32;
            a[x] = ascii;
        }

    }
    return lowerUpper(a, x + 1);
}

string lowerUpper4(string a, int b) {
    int x = b;
    if (x == 4) {
        return a;
    } else {
        if (a[x] >= 'a' && a[x] <= 'z') {
            int ascii = a[x];
            ascii = ascii - 32;
            a[x] = ascii;
        }

    }
    return lowerUpper4(a, x + 1);
}

string lowerUpper6(string a, int b) {
    int x = b;
    if (x == 6) {
        return a;
    } else {
        if (a[x] >= 'a' && a[x] <= 'z') {
            int ascii = a[x];
            ascii = ascii - 32;
            a[x] = ascii;
        }

    }
    return lowerUpper6(a, x + 1);
}

//Convert word to all lowercase

string upperLower(string a, int b) {
    int x = b;
    if (x == 5) {
        return a;
    } else {
        if (a[x] >= 'A' && a[x] <= 'Z') {
            int ascii = a[x];
            ascii = ascii + 32;
            a[x] = ascii;
        }

    }
    return upperLower(a, x + 1);
}

string upperLower4(string a, int b) {
    int x = b;
    if (x == 4) {
        return a;
    } else {
        if (a[x] >= 'A' && a[x] <= 'Z') {
            int ascii = a[x];
            ascii = ascii + 32;
            a[x] = ascii;
        }

    }
    return upperLower4(a, x + 1);
}

string upperLower6(string a, int b) {
    int x = b;
    if (x == 6) {
        return a;
    } else {
        if (a[x] >= 'A' && a[x] <= 'Z') {
            int ascii = a[x];
            ascii = ascii + 32;
            a[x] = ascii;
        }

    }
    return upperLower6(a, x + 1);
}

int selection = 0;
string Guess;
string Word;

int main() {

    cout << "\tWelcome to my recreation of the game Wordle!\n\n";
    do {

        cout << "\tWhat would you like to do?\n\t1. Guess a 5-letter word\tNORMAL\n\t2. Guess a 4-letter word\tEASY\n\t3. Guess a 6-letter word\tHARD\n\t4. Tutorial\n\t5. Exit\n";
        cin >> selection;

        switch (selection) {
            {

                case 1:
                {
                    Hash obj1;
                    Node *root = NULL;
                    tree avl;
                    char progress5[] = {'x', 'x', 'x', 'x', 'x'};

                    ifstream fin("5words.dat");
                    string temp;

                    while (fin >> temp) {
                        root = avl.insert(root, temp);
                    }

                    Word = avl.randomNode(root);
                    Word = lowerUpper(Word, 0);


                    //Declaring the variable that holds the guessed value
                    int attempts = 0;
                    while (attempts < 6) {


                        cout << "\n\n\n\n\n\n\n\nPlease guess a five-letter word: " << endl;

                        if (attempts > 0) {
                            obj1.returnLetters();
                            printProgress(progress5, 5);
                        }
                        cin >> Guess;
                        Guess = lowerUpper(Guess, 0);
                        //Checking word for errors

                        //Make sure word is 5 letters long
                        if (Guess.length() < 5 || Guess.length() > 5) {
                            while (Guess.length() != 5) {
                                cout << "Please enter a word that is 5 letters:" << endl;
                                printProgress(progress5, 5);
                                cin >> Guess;
                                Guess = lowerUpper(Guess, 0);
                            }
                        }

                        //Make sure word does not have any letters that were already used
                        for (int count = 0; count < 5; count++) {
                            int fattempts = 0;
                            if (obj1.returntF(Guess[count]) == false) {
                                cout << "\n\n\n\n\n\n\n\nThe letter (" << Guess[count] << ") has already been ruled out" << endl;
                                cout << "Please enter another five-letter word:" << endl;
                                printProgress(progress5, 5);
                                fattempts++;
                                while (obj1.returntF(Guess[0]) == false || obj1.returntF(Guess[1]) == false || obj1.returntF(Guess[2]) == false || obj1.returntF(Guess[3]) == false || obj1.returntF(Guess[4]) == false) {
                                    if (fattempts > 1) {
                                        cout << "\n\n\n\n\n\n\n\nYou cannot use any of these letters: " << endl;
                                        obj1.returnfalseLetters();
                                        cout << "Please enter another five-letter word:" << endl;
                                    }
                                    printProgress(progress5, 5);
                                    cin >> Guess;
                                    Guess = lowerUpper(Guess, 0);
                                    fattempts++;
                                }

                            }
                        }
                        //Storing word progress
                        for (int count = 0; count < 5; count++) {
                            if (Guess[count] == Word[count])
                                obj1.addItem(Guess[count], true);
                            else if (findLetter(Guess[count], Word, 0))
                                obj1.addItem(Guess[count], true);
                            else
                                obj1.addItem(Guess[count], false);
                        }
                        if (Guess == Word) {
                            Word = upperLower(Word, 0);
                            cout << "Congratulations, " << Guess << " is the correct word." << endl;
                            break;
                        }

                        //Storing accuracy
                        for (int count = 0; count < 5; count++) {
                            if (Guess[count] == Word[count]) {
                                progress5[count] = Guess[count];
                            }
                        }


                        attempts++;
                    }
                    if (attempts == 6) {
                        Word = upperLower(Word, 0);
                        cout << "Sorry, you have reached the guessing limit. The correct word was " << Word << "!\nPlay again?" << endl;
                    }
                    break;
                }
                case 2:
                {
                    Hash obj1;
                    Node *root = NULL;
                    tree avl;
                    char progress4[] = {'x','x','x','x'};
                    ifstream fin("4words.dat");
                    string temp;

                    while (fin >> temp) {
                        root = avl.insert(root, temp);
                    }

                    Word = avl.randomNode(root);
                    Word = lowerUpper4(Word, 0);

                    //Declaring the variable that holds the guessed value
                    int attempts = 0;
                    while (attempts < 6) {


                        cout << endl << "Please guess a four-letter word: " << endl;
                        if (attempts > 0) {
                            obj1.returnLetters();
                            printProgress(progress4, 4);
                        }
                        cin >> Guess;
                        Guess = lowerUpper4(Guess, 0);
                        //Checking word for errors
                        //Make sure word is 5 letters long
                        if (Guess.length() < 4 || Guess.length() > 4) {
                            while (Guess.length() != 4) {
                                cout << "Please enter a word that is 4 letters:" << endl;
                                printProgress(progress4, 4);
                                cin >> Guess;
                                Guess = lowerUpper4(Guess, 0);
                            }
                        }

                        //Make sure word does not have any letters that were already used
                        for (int count = 0; count < 4; count++) {
                            int fattempts = 0;
                            if (obj1.returntF(Guess[count]) == false) {
                                cout << "The letter (" << Guess[count] << ") has already been ruled out" << endl;
                                cout << "Please enter another four-letter word:" << endl;
                                fattempts++;
                                while (obj1.returntF(Guess[0]) == false || obj1.returntF(Guess[1]) == false || obj1.returntF(Guess[2]) == false || obj1.returntF(Guess[3]) == false || obj1.returntF(Guess[4]) == false) {
                                    if (fattempts > 1) {
                                        cout << "You cannot use any of these letters: " << endl;
                                        obj1.returnfalseLetters();
                                    }
                                    printProgress(progress4, 4);
                                    cin >> Guess;
                                    Guess = lowerUpper4(Guess, 0);
                                    fattempts++;
                                }

                            }
                        }
                        //Storing word progress
                        for (int count = 0; count < 5; count++) {
                            if (Guess[count] == Word[count])
                                obj1.addItem(Guess[count], true);
                            else if (findLetter4(Guess[count], Word, 0))
                                obj1.addItem(Guess[count], true);
                            else
                                obj1.addItem(Guess[count], false);
                        }
                        if (Guess == Word) {
                            Word = upperLower4(Word, 0);
                            cout << "Congratulations, " << Guess << " is the correct word." << endl;
                            break;
                        }

                        attempts++;
                    }
                    if (attempts == 6) {
                        Word = upperLower(Word, 0);
                        cout << "Sorry, you have reached the guessing limit. The correct word was " << Word << "!\nPlay again?" << endl;
                    }
                    break;
                }
                case 3:
                {
                    Hash obj1;
                    Node *root = NULL;
                    tree avl;
                    char progress6[] = {'x','x','x','x','x','x'};
                    ifstream fin("6words.dat");
                    string temp;

                    while (fin >> temp) {
                        root = avl.insert(root, temp);
                    }

                    Word = avl.randomNode(root);
                    Word = lowerUpper6(Word, 0);

                    //Declaring the variable that holds the guessed value
                    int attempts = 0;
                    while (attempts < 6) {


                        cout << endl << "Please guess a four-letter word: " << endl;
                        if (attempts > 0) {
                            obj1.returnLetters();
                            printProgress(progress6, 6);
                        }
                        cin >> Guess;
                        Guess = lowerUpper6(Guess, 0);
                        //Checking word for errors
                        //Make sure word is 5 letters long
                        if (Guess.length() < 6 || Guess.length() > 6) {
                            while (Guess.length() != 4) {
                                cout << "Please enter a word that is 4 letters:" << endl;
                                printProgress(progress6, 6);
                                cin >> Guess;
                                Guess = lowerUpper6(Guess, 0);
                            }
                        }

                        //Make sure word does not have any letters that were already used
                        for (int count = 0; count < 6; count++) {
                            int fattempts = 0;
                            if (obj1.returntF(Guess[count]) == false) {
                                cout << "The letter (" << Guess[count] << ") has already been ruled out" << endl;
                                cout << "Please enter another four-letter word:" << endl;
                                printProgress(progress6, 6);
                                fattempts++;
                                while (obj1.returntF(Guess[0]) == false || obj1.returntF(Guess[1]) == false || obj1.returntF(Guess[2]) == false || obj1.returntF(Guess[3]) == false || obj1.returntF(Guess[4]) == false) {
                                    if (fattempts > 1) {
                                        cout << "You cannot use any of these letters: " << endl;
                                        obj1.returnfalseLetters();
                                    }
                                    printProgress(progress6, 6);
                                    cin >> Guess;
                                    Guess = lowerUpper6(Guess, 0);
                                    fattempts++;
                                }

                            }
                        }
                        //Storing word progress
                        for (int count = 0; count < 5; count++) {
                            if (Guess[count] == Word[count])
                                obj1.addItem(Guess[count], true);
                            else if (findLetter6(Guess[count], Word, 0))
                                obj1.addItem(Guess[count], true);
                            else
                                obj1.addItem(Guess[count], false);
                        }
                        if (Guess == Word) {
                            Word = lowerUpper6(Word, 0);
                            cout << "Congratulations, " << Guess << " is the correct word." << endl;
                            break;
                        }

                        attempts++;
                    }
                    if (attempts == 6) {
                        Word = upperLower(Word, 0);
                        cout << "Sorry, you have reached the guessing limit. The correct word was " << Word << "!\nPlay again?" << endl;
                    }
                    break;
                }
                break;
                case 4:
                cout << "\n\n\tThe rules of the game are simple:" << endl <<
                        "\t\t1. Choose the version of the game you would like to play." << endl <<
                        "\t\t\ta. Guess a 4 letter word\tEASY\n\t\t\tb. Guess a 5 letter word\tINTERMEDIATE\n\t\t\tc. Guess a 6 letter word\tHARD\n" <<
                        "\t\t2. A random word of the word size you chose will be generated. You only have 6 tries to guess it" <<
                        "\n\t\t3. When you incorrectly guess a letter, it will be removed from the LIST OF AVAILABLE LETTERS\n" <<
                        "\t\t4. If you guess a letter correctly, but not in the right location, it will appear in the LIST OF CORRECT LETTERS\n" <<
                        "\t\t5. If you guess the letters location, it will appear in the selection bar\n" <<
                        "\t\t6. All letters that haven't been guessed will be displayed as '_'" << endl <<
                        "\t\tGet Guessing!\n\n\n";
                break;
                case 5:
                cout << "\n\n\tThank you for playing!";
                break;
            }
        }
    } while (selection != 5);


    return 0;
}

