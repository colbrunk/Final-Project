#include <iostream>
using namespace std;

#ifndef HASH_H
#define HASH_H

class Hash{
private:
    static const int tableSize = 26;
    
    struct item{
        char letter;
        bool tF;
        item* next;
    };
    
    item* HashTable[tableSize];
public:
    Hash();
    int hash(char key);
    void addItem(char letter, bool tF);
    int numberItems(int index);
    void printTable();
    bool returntF(char);
    void returnLetters();
    void returnfalseLetters();
};
#endif /* HASH_H */

