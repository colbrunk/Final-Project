#include <iostream>
#include "hash.h"
using namespace std;

Hash::Hash() {
    for (int count = 0; count < tableSize; count++) {
        HashTable[count] = new item;
        HashTable[count]->letter = 'x';
        HashTable[count]->tF = true;
        HashTable[count]->next = NULL;
    }
}

int Hash::hash(char key) {
    return (int) key % tableSize;
}

void Hash::addItem(char l, bool trueF) {
    int index = hash(l);
    if (HashTable[index]->letter == 'x') {
        HashTable[index]->letter = l;
        HashTable[index]->tF = trueF;
    } else {
        item* Ptr = HashTable[index];
        item* n = new item;
        n->letter = l;
        n->tF = trueF;
        n->next = NULL;
        while (Ptr->next != NULL) {
            Ptr = Ptr->next;
        }
        Ptr->next = n;
    }
}

int Hash::numberItems(int i) {
    int count = 0;
    if (HashTable[i]->letter == 'x')
        return count;
    else {
        count++;
        item* Ptr = HashTable[i];
        while (Ptr->next != NULL) {
            count++;
            Ptr = Ptr->next;
        }
    }
    return count;
}

void Hash::printTable() {
    int number;
    for (int count = 0; count < tableSize; count++) {
        number = numberItems(count);
        cout << "\nIndex: = " << count << endl;
        cout << HashTable[count]->letter << endl;
        cout << HashTable[count]->tF << endl;
        cout << "# of items = " << number << endl;
    }
}

bool Hash::returntF(char a) {
    for (int count = 0; count < tableSize; count++) {
        item *Ptr = HashTable[count];
        if (a == Ptr->letter) {
            return Ptr->tF;
        }
    }
    return true;
}

void Hash::returnLetters() {
    int number;
    cout << "\nLetters that you have incorrectly guessed: " << endl;
    for (int count = 0; count < tableSize; count++) {
        if (HashTable[count]->letter != 'x' && HashTable[count]->tF == false) {
            cout << HashTable[count]->letter << " ";
        }
    }
    cout << "\nLetters that you have correctly guessed: " << endl;
    for (int count = 0; count < tableSize; count++) {
        if (HashTable[count]->letter != 'x' && HashTable[count]->tF == true) {
            cout << HashTable[count]->letter << " ";
        }
    }
    cout << endl << endl;
}

void Hash::returnfalseLetters() {
    for (int count = 0; count < tableSize; count++) {
        if (HashTable[count]->letter != 'x' && HashTable[count]->tF == true) {
            cout << HashTable[count]->letter << " ";
        }
    }
    cout << endl;
}